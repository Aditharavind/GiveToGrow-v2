from django.db import models

# Model for donation items


class Donation(models.Model):
    CAUSE_CHOICES = [
        ('Education', 'Education Support'),
        ('Food', 'Food Donation'),
        ('Healthcare', 'Healthcare Assistance'),
        ('Shelter', 'Shelter Provision'),
    ]
    
    name = models.CharField(max_length=255)
    email = models.EmailField()
    cause = models.CharField(max_length=50, choices=CAUSE_CHOICES)
    food_type = models.CharField(max_length=255, blank=True, null=True)  # Optional for non-food donations
    food_quantity = models.CharField(max_length=100, blank=True, null=True)  # Optional for non-food donations
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.cause}"



# Model for orphanages
class Orphanage(models.Model):
    name = models.CharField(max_length=100)
    location = models.CharField(max_length=255)
    contact = models.CharField(max_length=15)
    amount_needed = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.name


# Model for educational institutions
class EducationalInstitution(models.Model):
    name = models.CharField(max_length=100)
    institution_type = models.CharField(max_length=100)
    location = models.CharField(max_length=255)
    amount_needed = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.name

class UserRegistration(models.Model):
    USER_TYPE_CHOICES = [
        ('Donor', 'Donor'),
        ('Volunteer', 'Volunteer'),
        ('Organization', 'Organization'),
    ]

    full_name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    user_type = models.CharField(max_length=50, choices=USER_TYPE_CHOICES)
    password = models.CharField(max_length=255)  # In a real app, you'd store hashed passwords

    def __str__(self):
        return self.full_name

class UserRegistration(models.Model):
    USER_TYPE_CHOICES = [
        ('Donor', 'Donor'),
        ('Volunteer', 'Volunteer'),
        ('Organization', 'Organization'),
    ]

    full_name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    user_type = models.CharField(max_length=50, choices=USER_TYPE_CHOICES)
    password = models.CharField(max_length=255)  # In a real app, you'd store hashed passwords

    def __str__(self):
        return self.full_name