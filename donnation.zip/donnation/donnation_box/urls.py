from django.contrib import admin
from django.urls import path,include
from .import views

urlpatterns = [
    path('',views.index,name="home-page"),
    path('userhome',views.userhome,name="userhome"),
    path('vol',views.vol,name="vol"),
    path('login',views.login,name="login"),
    path('register',views.register,name="register"),
    path('donate',views.donate,name="donate"),
    
]
