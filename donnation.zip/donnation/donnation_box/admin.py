from django.contrib import admin
from .models import Donation, Orphanage, EducationalInstitution,UserRegistration
# Register your models here.

admin.site.register(UserRegistration)