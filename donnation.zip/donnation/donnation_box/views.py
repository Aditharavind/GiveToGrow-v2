from django.shortcuts import render
from .models import Donation, Orphanage, EducationalInstitution,UserRegistration
from django.db import IntegrityError
from django.contrib.auth.hashers import make_password
from django.shortcuts import render, redirect
from django.contrib.auth.hashers import check_password

# Create your views here.
def index(request):
    return render(request,'index.html')
def userhome(request):
    items = Donation.objects.all()
    orphanages = Orphanage.objects.all()
    institutions = EducationalInstitution.objects.all()
    return render(request,'user.html',{
        'Donation':Donation,
        'orphanages':orphanages,
        'institutions':institutions
        })
#vol-home
def vol(request):
    return render(request,'vol.html')

#userreg


def donate(request):
    return render(request,'don.html')

def register(request):
    if request.method == 'POST':
        # Get form data
        full_name = request.POST.get('full_name')
        email = request.POST.get('email')
        user_type = request.POST.get('user_type')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        # Debugging: Print to ensure data is received correctly
        print(f"Full Name: {full_name}, Email: {email}, User Type: {user_type}, Password: {password}")

        # Basic validation for password confirmation
        if password != confirm_password:
            return render(request, 'reg.html', {'error': 'Passwords do not match'})

        try:
            # Save the user registration data
            user = UserRegistration(
                full_name=full_name,
                email=email,
                user_type=user_type,
                password=make_password(password)  # Hash the password before saving
            )
            user.save()
            # Redirect to login page after successful registration
            return redirect('login')  # 'login' should be the name of your login URL
        except IntegrityError:
            # Handle the case where the email already exists
            return render(request, 'reg.html', {'error': 'Email already exists'})

    return render(request, 'reg.html')

   


def login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Try to get the user from the database
        try:
            user = UserRegistration.objects.get(email=email)
        except UserRegistration.DoesNotExist:
            return render(request, 'login.html', {'error': 'Invalid email or password'})

        # Check if the password is correct
        if check_password(password, user.password):
            # Redirect based on user type
            if user.user_type == 'Volunteer':
                return redirect('vol')  # 'volunteer_page' should map to vol.html
            elif user.user_type == 'User':
                return redirect('userhome')  # 'user_page' should map to user.html
            else:
                return render(request, 'login.html', {'error': 'Invalid user type'})
        else:
            return render(request, 'login.html', {'error': 'Invalid email or password'})

    return render(request, 'login.html')


